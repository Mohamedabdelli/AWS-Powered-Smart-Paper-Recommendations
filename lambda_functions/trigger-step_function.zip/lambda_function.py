import boto3
import logging
from botocore.exceptions import ClientError
import os
# Initialisation du client Step Functions
stepfunctions = boto3.client('stepfunctions')
# Configuration du logger
logger = logging.getLogger()
logger.setLevel(logging.INFO)
arn_step_function =os.environ["arn_step_function"]
def lambda_handler(event, context):
    for record in event['Records']:
        query = record['body']  # Récupère le message SQS (contenant l'URL)
        
        try:
            # Déclenche la Step Function avec l'URL en entrée
            response = stepfunctions.start_execution(
                stateMachineArn=arn_step_function,
                input=f'{{"query": "{query}"}}'
            )
            logger.info(f"Step Function triggered for query: {query}")
        except ClientError as e:
            logger.error(f"Error triggering Step Function for query: {query}. Error: {str(e)}")
            # Si la Lambda échoue, le message sera réessayer automatiquement par SQS.
            raise e

    return {"status": "Step Function triggered"}
