from chalice import Chalice
from pinecone import Pinecone
import boto3
import json
import os

app = Chalice(app_name='test-tf-deploy')

# Configuration pour accéder à SageMaker, Pinecone, SQS et DynamoDB
client = boto3.client("sagemaker-runtime")
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
region_name = os.environ['region_name']

# Initialisation du client Pinecone avec la clé API
api_key_pinecone = os.environ['api_key_pinecone']
pinecone = Pinecone(api_key=api_key_pinecone)
INDEX_NAME = os.environ['INDEX_NAME']
index = pinecone.Index(INDEX_NAME)

# Initialisation du client Bedrock
bedrock_runtime = boto3.client('bedrock-runtime', region_name=region_name)

# Nom des ressources
ENDPOINT_NAME = os.environ['ENDPOINT_NAME']
TABLE_NAME = os.environ["TABLE_NAME"]
QUEUE_URL = os.environ["QUEUE_URL"]

# Initialisation du client SQS
sqs = boto3.client('sqs', region_name=region_name)

def get_embeddings(liste_doc):
    try:
        body = {"inputs": liste_doc}
        response = client.invoke_endpoint(
            EndpointName=ENDPOINT_NAME,
            ContentType="application/json",
            Accept="application/json",
            Body=json.dumps(body),
        )
        response_body = response['Body'].read().decode('utf-8')
        result = json.loads(response_body)
        return result
    except Exception as e:
        app.log.error(f"Erreur lors de l'appel à SageMaker: {str(e)}")
        return None

def get_recommendations(pinecone_index, search_term, top_k=3):
    embed = get_embeddings([search_term])
    if embed is None:
        return None, "Erreur lors de la génération des embeddings."
    
    try:
        res = pinecone_index.query(vector=embed[0], top_k=top_k, include_metadata=True, namespace="ns1")
        context = ""
        rec = []
        for match in res['matches']:
            context += match['metadata']['body'] + "\n===\n"
            rec.append({
                'id': match['metadata']['id'], 
                'score': match['score'],
                'content': match['metadata']['body']
            })
        return rec, context
    except Exception as e:
        app.log.error(f"Erreur lors de l'interrogation de Pinecone: {str(e)}")
        return None, "Erreur lors de la recherche de recommandations."

def get_prompt(question, context):
    RAG_PROMPT_TEMPLATE = """
    Your task is to answer the following question using only the provided context.
    Do not include any introductory phrases or explanations. 
    Provide only the direct answer, written in your own words, and ensure it is at least 300 characters.

    %CONTEXT%
    {context}

    %Question%
    {question}

    Answer:
    """
    prompt = RAG_PROMPT_TEMPLATE.format(question=question, context=context)
    return prompt

def response_with_bedrock(query, context):
    try:
        prompt = get_prompt(query, context)
        prompt = "Human: " + prompt + "\n\nAssistant:"

        body = json.dumps({
            "prompt": prompt,
            "max_tokens_to_sample": 2048,
            "temperature": 0.7,
            "stop_sequences": []
        })

        # Appel au modèle
        response = bedrock_runtime.invoke_model(
            body=body,
            modelId="anthropic.claude-v2",
            accept='application/json',
            contentType='application/json'
        )

        # Lecture de la réponse
        response_body = json.loads(response.get('body').read())
        completion = response_body.get('completion').strip()  # Suppression des espaces blancs inutiles
        return completion
    except Exception as e:
        app.log.error(f"Erreur lors de l'appel au modèle Bedrock: {str(e)}")
        return "Erreur lors de la génération de la réponse."

def get_from_id(profile_id, table_name):
    try:
        customer_table = dynamodb.Table(table_name)
        response = customer_table.get_item(Key={'id': profile_id})
        return response.get('Item', None)
    except Exception as e:
        app.log.error(f"Erreur lors de l'accès à DynamoDB: {str(e)}")
        return None

@app.route('/register', methods=['POST'])
def register_user():
    request = app.current_request
    request_data = request.json_body

    if 'query' not in request_data:
        return {'error': 'query is required'}

    query = request_data['query']
    print('query', query)

    try:
        # Envoyer l'URL LinkedIn à la file SQS
        response = sqs.send_message(
            QueueUrl=QUEUE_URL,
            MessageBody=query
        )
        return {'message': 'query registered successfully', 'sqs_message_id': response.get('MessageId')}
    except Exception as e:
        app.log.error(f"Erreur lors de l'envoi du message SQS: {str(e)}")
        return {'error': 'Erreur lors de l\'enregistrement de la requête.'}

@app.route('/recommend', methods=['POST'])
def search_profile():
    request = app.current_request
    request_data = request.json_body

    if 'query' not in request_data:
        return {'error': 'query parameter is required'}

    query = request_data['query']

    # Obtenir les recommandations basées sur la requête
    recom, context = get_recommendations(index, query)
    if recom is None:
        return {'error': 'Erreur lors de la génération des recommandations.'}

    answer = response_with_bedrock(query, context)

    profiles = []
    seen_ids = set()  # Ensemble pour suivre les ID déjà traités

    for rec in recom:
        profile_id = rec['id']
        
        # Vérifier si l'ID a déjà été traité
        if profile_id not in seen_ids:
            seen_ids.add(profile_id)  # Ajouter l'ID à l'ensemble des vus
            
            # Récupérer les données depuis DynamoDB
            profile_data = get_from_id(profile_id, TABLE_NAME)
            if profile_data:
                profiles.append(profile_data)
    
    if not profiles:
        return {'error': 'No profiles found'}    

    return {"profils": profiles, "answer": answer}
